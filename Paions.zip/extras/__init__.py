from extras.callmanager import MusicPlayer
from extras import queues

music_player = MusicPlayer()
__al__ = [
    "music_player",
    "queues",
    "clear",
    "get",
    "is_empty",
    "put",
    "task_done",
    "size",
]
